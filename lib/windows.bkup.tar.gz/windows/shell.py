import argparse
import sys
import string
import sw_xem_library

class Command:
	def __init__(self, _cmd="", _func=None):
		self.cmd = _cmd
		self.func = _func
		return
	
	def run(self, params):
		return self.func(params)


def openDevice(serial=None):
	dev = sw_xem_library.Device(verbose)
	if (dev.Initialize(serial) == False):
		return None
	return dev

def getInfo(params):
	if (len(params) != 0):
		return False
	
	info = dev.getInfo()
	if (info == None):
		return False
	print("         Product: " + info.productName)
	print("Firmware version: %d.%d" % (info.deviceMajorVersion, info.deviceMinorVersion))
	print("   Serial Number: %s" % info.serialNumber)
	print("       Device ID: %s" % info.deviceID)
	
	return True

def setupClock(params):
	if (len(params) != 0):
		return False
		
	dev.setupClock()
	
	return True

def downloadFile(params):
	if (len(params) != 1):
		return False
		
	print("t" if dev.downloadFile(params[0]) else "f")
	
	return 

def checkFrontPanel(params):
	if (len(params) != 0):
		return False
		
	print("t" if dev.checkFrontPanel() else "f")
	
	return True

def setWire(params):
	if (len(params) not in {2, 3}):
		return False
		
	if (len(params) == 2):
		dev.setWire(int(params[0]), int(params[1]))
	else:
		dev.setWire(int(params[0]), int(params[1]), int(params[2]))
	
	return True

def setTrigger(params):
	if (len(params) != 2):
		return False
		
	dev.setTrigger(int(params[0]), int(params[1]))
	
	return True

def checkTrigger(params):
	if (len(params) != 2):
		return False
		
	print("t" if dev.checkTrigger(int(params[0]), int(params[1])) else "f")
	
	return True

def writeString(params):
	if (len(params) != 2):
		return False
		
	dev.writeString(int(params[0]), params[1])
	
	return True

def readString(params):
	if (len(params) != 2):
		return False
	
	text = dev.readString(int(params[0]), int(params[1]))
	print(text)
	
	return True


def Parse(cmd, params):
	obj = next((x for x in commands if x.cmd == cmd), None)
	if (obj == None):
		return False
	
	obj.run(params)
	
	return True


verbose = False
def CPrint(text):
	if (verbose == True):
		print(text)


commands = {
	Command("getInfo", getInfo),
	Command("setupClock", setupClock),
	Command("downloadFile", downloadFile),
	Command("checkFrontPanel", checkFrontPanel),
	Command("setWire", setWire),
	Command("setTrigger", setTrigger),
	Command("checkTrigger", checkTrigger),
	Command("writeString", writeString),
	Command("readString", readString)
}


dev = None
# Main code
parser = argparse.ArgumentParser()
parser.add_argument("-v", "--verbose", help="increase output verbosity", action="store_true")
parser.add_argument("-n", "--number", help="select board by its Serial Number")
parser.add_argument("command", help="command to be executed")
parser.add_argument("parameters", nargs='*', help="command to be executed")
args = parser.parse_args()

if (args.verbose):
	verbose = True

if (args.number):
	dev = openDevice(args.number)
else:
	dev = openDevice()
if (dev == None):
	CPrint("ERROR")
	exit(1)

if (args.parameters):
	result = Parse(args.command, args.parameters)
else:
	result = Parse(args.command, [])

if (result == False):
	CPrint("ERROR")
	exit(1)

CPrint("OK")
exit(0)
